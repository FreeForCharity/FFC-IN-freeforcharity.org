DROP TABLE IF EXISTS `wp_wpmudev_chat_log_CCXVsb4YOpPd`;
CREATE TABLE `wp_wpmudev_chat_log_CCXVsb4YOpPd` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `chat_id` varchar(40) NOT NULL,
  `session_type` varchar(40) NOT NULL,
  `messages_count` int(11) NOT NULL,
  `users_count` int(11) NOT NULL,
  `start` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `chat_id` (`chat_id`),
  KEY `session_type` (`session_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `wp_wpmudev_chat_log`;
RENAME TABLE `wp_wpmudev_chat_log_CCXVsb4YOpPd` TO `wp_wpmudev_chat_log`;