DROP TABLE IF EXISTS `wp_users_CCXVsb4YOpPd`;
CREATE TABLE `wp_users_CCXVsb4YOpPd` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `wp_users_CCXVsb4YOpPd` VALUES
('1','GlobalAdmin','$P$Bzk1eboIFkP6ywGZ4fyWwb82CNyy7P1','admin','test@test.com','','2013-01-06 22:18:58','','0','Global'),
('3','Clarke Moyer','$P$B8xH9RYytR/LMxl4GENyoTVz7WBpfD/','clarke-moyer','clarkemoyer@freeforcharity.org','http://www.freeforcharity.org','2013-08-14 22:37:31','','0','Clarke Moyer'),
('4','Early Learning Centers of Rhode Island','$P$BtxOz/WD8ZnfRcxfkdfDEJtei6Ep3s0','early-learning-centers-of-rhode-island','elcofri@yahoo.com','','2013-08-14 22:37:53','','0','Early Learning Centers of Rhode Island'),
('5','wkalson','$P$BVfLIbrb.KUnZ8fMelDP9hFwWlpz6J.','wkalson','wkalson@hotmail.com','','2013-08-16 22:38:52','','0','wkalson'),
('6','natimisktaw','$P$BMuZnSr/v7iVxKCF3FdLYc31Ga5gaZ/','natimisktaw','gxhkxmu1hxcaig@gmail.com','','2013-09-05 14:09:44','','0','natimisktaw'),
('7','z34b19ry0','$P$BvITn8y51qGvUlG2iO5X0Wh7pl8TUb0','z34b19ry0','oliniga@hotmail.com','','2013-09-06 21:51:34','','0','z34b19ry0'),
('8','april-moyer-7','$P$B73nq1coM5opg2FUYepCpAnvJyAxU8.','april-moyer-7','aprilmoyer@gmail.com','https://www.facebook.com/april.moyer.7','2013-09-09 14:38:11','','0','April Moyer'),
('9','Marianatax','$P$B.Np9TVbtKjegO.33SW.v0/Fq5gxIG0','marianatax','sappmoguragtama1974@yandex.com','','2013-09-14 01:25:38','','0','Marianatax'),
('10','Makenziexxx','$P$Bv8RHziLHIyAeWTHAGk20jkEyT8APL1','makenziexxx','spbgirlswhere@hotmail.com','','2013-09-18 18:08:03','','0','Makenziexxx'),
('11','oDeskAdmin','$P$BmC1/zqtv9zB1LYN2nG0Ov/qxyW4ol/','odeskadmin','test1@test.com','','2013-10-15 11:15:58','','0','oDesk Admin');

DROP TABLE IF EXISTS `wp_users`;
RENAME TABLE `wp_users_CCXVsb4YOpPd` TO `wp_users`;