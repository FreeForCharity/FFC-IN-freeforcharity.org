DROP TABLE IF EXISTS `wp_subscriptions_CCXVsb4YOpPd`;
CREATE TABLE `wp_subscriptions_CCXVsb4YOpPd` (
  `subscription_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subscription_email` varchar(100) NOT NULL,
  `subscription_type` varchar(200) NOT NULL,
  `subscription_created` bigint(20) NOT NULL,
  `subscription_note` varchar(200) NOT NULL,
  `confirmation_flag` tinyint(1) DEFAULT '0',
  `user_key` varchar(50) NOT NULL,
  `subscription_settings` text,
  PRIMARY KEY (`subscription_ID`),
  UNIQUE KEY `subscription_email` (`subscription_email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `wp_subscriptions`;
RENAME TABLE `wp_subscriptions_CCXVsb4YOpPd` TO `wp_subscriptions`;