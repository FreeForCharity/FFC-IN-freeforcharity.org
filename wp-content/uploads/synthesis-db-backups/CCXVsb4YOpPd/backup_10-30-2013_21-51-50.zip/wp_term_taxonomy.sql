DROP TABLE IF EXISTS `wp_term_taxonomy_CCXVsb4YOpPd`;
CREATE TABLE `wp_term_taxonomy_CCXVsb4YOpPd` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `wp_term_taxonomy_CCXVsb4YOpPd` VALUES
('1','1','category','','0','1'),
('2','2','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','0','0'),
('3','3','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','0','0'),
('4','4','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','0','0'),
('5','5','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','0','0'),
('6','6','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','0','0'),
('7','7','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','2','0'),
('8','8','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','2','0'),
('9','9','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','2','0'),
('10','10','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','7','0'),
('11','11','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','7','0'),
('12','12','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','7','0'),
('13','13','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','10','0'),
('14','14','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','10','0'),
('15','15','category','This is an sample category description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Category screen in your dashboard.','10','0'),
('16','16','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('17','17','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('18','18','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('19','19','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('20','20','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('21','21','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('22','22','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('23','23','post_tag','This is an sample tag description, which can be used to boost SEO rankings.  Make sure you enabled this from the Edit Post Tags screen in your dashboard.','0','0'),
('24','24','nav_menu','','0','14'),
('25','25','nav_menu','','0','4'),
('26','26','nav_menu','','0','6'),
('27','27','listing_category','','0','0'),
('28','28','listing_category','','27','0');

DROP TABLE IF EXISTS `wp_term_taxonomy`;
RENAME TABLE `wp_term_taxonomy_CCXVsb4YOpPd` TO `wp_term_taxonomy`;