DROP TABLE IF EXISTS `wp_support_tickets_cats_CCXVsb4YOpPd`;
CREATE TABLE `wp_support_tickets_cats_CCXVsb4YOpPd` (
  `cat_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `defcat` enum('0','1') NOT NULL DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `cat_name` (`cat_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_support_tickets_cats_CCXVsb4YOpPd` VALUES
('1','1','General','1','0');

DROP TABLE IF EXISTS `wp_support_tickets_cats`;
RENAME TABLE `wp_support_tickets_cats_CCXVsb4YOpPd` TO `wp_support_tickets_cats`;