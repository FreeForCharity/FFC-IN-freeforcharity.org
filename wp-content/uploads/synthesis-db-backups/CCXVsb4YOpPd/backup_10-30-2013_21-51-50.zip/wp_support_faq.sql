DROP TABLE IF EXISTS `wp_support_faq_CCXVsb4YOpPd`;
CREATE TABLE `wp_support_faq_CCXVsb4YOpPd` (
  `faq_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned NOT NULL,
  `cat_id` bigint(20) unsigned NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` mediumtext NOT NULL,
  `help_views` bigint(20) unsigned NOT NULL DEFAULT '0',
  `help_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  `help_yes` int(12) unsigned NOT NULL DEFAULT '0',
  `help_no` int(12) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`faq_id`),
  KEY `site_id` (`site_id`,`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `wp_support_faq`;
RENAME TABLE `wp_support_faq_CCXVsb4YOpPd` TO `wp_support_faq`;