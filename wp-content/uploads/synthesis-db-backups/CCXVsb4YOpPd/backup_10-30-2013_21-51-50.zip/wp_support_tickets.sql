DROP TABLE IF EXISTS `wp_support_tickets_CCXVsb4YOpPd`;
CREATE TABLE `wp_support_tickets_CCXVsb4YOpPd` (
  `ticket_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned NOT NULL,
  `blog_id` bigint(20) unsigned NOT NULL,
  `cat_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `admin_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `last_reply_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ticket_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ticket_priority` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ticket_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ticket_opened` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ticket_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `num_replies` smallint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL,
  `view_by_superadmin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticket_id`),
  KEY `site_id` (`site_id`),
  KEY `blog_id` (`blog_id`),
  KEY `user_id` (`user_id`),
  KEY `admin_id` (`admin_id`),
  KEY `ticket_status` (`ticket_status`),
  KEY `ticket_updated` (`ticket_updated`),
  KEY `view_by_superadmin` (`view_by_superadmin`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `wp_support_tickets`;
RENAME TABLE `wp_support_tickets_CCXVsb4YOpPd` TO `wp_support_tickets`;