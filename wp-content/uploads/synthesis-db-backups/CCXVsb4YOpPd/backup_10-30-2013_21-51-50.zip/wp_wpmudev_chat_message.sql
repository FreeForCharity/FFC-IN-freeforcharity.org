DROP TABLE IF EXISTS `wp_wpmudev_chat_message_CCXVsb4YOpPd`;
CREATE TABLE `wp_wpmudev_chat_message_CCXVsb4YOpPd` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `chat_id` varchar(40) NOT NULL,
  `session_type` varchar(40) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(255) NOT NULL,
  `avatar` varchar(1024) NOT NULL,
  `auth_hash` varchar(50) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `moderator` enum('no','yes') NOT NULL DEFAULT 'no',
  `deleted` enum('no','yes') NOT NULL DEFAULT 'no',
  `archived` enum('no','yes') NOT NULL DEFAULT 'no',
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `chat_id` (`chat_id`),
  KEY `auth_hash` (`auth_hash`),
  KEY `session_type` (`session_type`),
  KEY `timestamp` (`timestamp`),
  KEY `archived` (`archived`),
  KEY `log_id` (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_wpmudev_chat_message_CCXVsb4YOpPd` VALUES
('1','0','wpmudevchatwidget-2','widget','2013-10-05 22:08:02','admin','http://1.gravatar.com/avatar/b642b4217b34b1e8d3bd915fc65c4452?s=96&amp;d=blank&amp;r=PG','c4ca4238a0b923820dcc509a6f75849b','215.68.72.250','Test','no','no','no','0');

DROP TABLE IF EXISTS `wp_wpmudev_chat_message`;
RENAME TABLE `wp_wpmudev_chat_message_CCXVsb4YOpPd` TO `wp_wpmudev_chat_message`;