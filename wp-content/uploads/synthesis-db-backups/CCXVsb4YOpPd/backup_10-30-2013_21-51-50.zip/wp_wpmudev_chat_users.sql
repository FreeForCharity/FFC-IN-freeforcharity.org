DROP TABLE IF EXISTS `wp_wpmudev_chat_users_CCXVsb4YOpPd`;
CREATE TABLE `wp_wpmudev_chat_users_CCXVsb4YOpPd` (
  `blog_id` bigint(20) unsigned NOT NULL,
  `chat_id` varchar(40) NOT NULL,
  `auth_hash` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `moderator` enum('no','yes') NOT NULL DEFAULT 'no',
  `last_polled` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `entered` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_address` varchar(39) NOT NULL DEFAULT '',
  PRIMARY KEY (`blog_id`,`chat_id`,`auth_hash`),
  KEY `blog_id` (`blog_id`),
  KEY `chat_id` (`chat_id`),
  KEY `auth_hash` (`auth_hash`),
  KEY `last_polled` (`last_polled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_wpmudev_chat_users_CCXVsb4YOpPd` VALUES
('0','wpmudevchatwidget-2','c4ca4238a0b923820dcc509a6f75849b','admin','http://1.gravatar.com/avatar/b642b4217b34b1e8d3bd915fc65c4452?s=96&amp;d=blank&amp;r=PG','no','2013-10-05 15:19:37','2013-10-05 15:07:44','215.68.72.250');

DROP TABLE IF EXISTS `wp_wpmudev_chat_users`;
RENAME TABLE `wp_wpmudev_chat_users_CCXVsb4YOpPd` TO `wp_wpmudev_chat_users`;