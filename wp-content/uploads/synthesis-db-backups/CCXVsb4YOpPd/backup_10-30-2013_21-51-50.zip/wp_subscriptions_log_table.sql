DROP TABLE IF EXISTS `wp_subscriptions_log_table_CCXVsb4YOpPd`;
CREATE TABLE `wp_subscriptions_log_table_CCXVsb4YOpPd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mail_subject` text NOT NULL,
  `mail_recipients` int(8) NOT NULL,
  `mail_date` bigint(20) NOT NULL,
  `mail_settings` text,
  `mails_list` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `wp_subscriptions_log_table`;
RENAME TABLE `wp_subscriptions_log_table_CCXVsb4YOpPd` TO `wp_subscriptions_log_table`;