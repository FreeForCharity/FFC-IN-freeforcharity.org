DROP TABLE IF EXISTS `wp_support_tickets_messages_CCXVsb4YOpPd`;
CREATE TABLE `wp_support_tickets_messages_CCXVsb4YOpPd` (
  `message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned NOT NULL,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `admin_id` bigint(20) unsigned NOT NULL,
  `message_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subject` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `attachments` text,
  PRIMARY KEY (`message_id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `wp_support_tickets_messages`;
RENAME TABLE `wp_support_tickets_messages_CCXVsb4YOpPd` TO `wp_support_tickets_messages`;