DROP TABLE IF EXISTS `wp_support_faq_cats_CCXVsb4YOpPd`;
CREATE TABLE `wp_support_faq_cats_CCXVsb4YOpPd` (
  `cat_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `qcount` smallint(3) unsigned NOT NULL,
  `defcat` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `cat_name` (`cat_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `wp_support_faq_cats_CCXVsb4YOpPd` VALUES
('1','1','General questions','0','1');

DROP TABLE IF EXISTS `wp_support_faq_cats`;
RENAME TABLE `wp_support_faq_cats_CCXVsb4YOpPd` TO `wp_support_faq_cats`;