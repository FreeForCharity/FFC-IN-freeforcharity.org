DROP TABLE IF EXISTS `wp_terms_7eVrCiFOsqnL`;
CREATE TABLE `wp_terms_7eVrCiFOsqnL` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `wp_terms_7eVrCiFOsqnL` VALUES
('1','Uncategorized','uncategorized','0'),
('2','Category #1','category-1','0'),
('3','Category #2','category-2','0'),
('4','Category #3','category-3','0'),
('5','Category #4','category-4','0'),
('6','Category #5','category-5','0'),
('7','Sub Category 1.1','sub-category-11','0'),
('8','Sub Category 1.2','sub-category-12','0'),
('9','Sub Category 1.3','sub-category-13','0'),
('10','Sub Category 2.1','sub-category-21','0'),
('11','Sub Category 2.2','sub-category-22','0'),
('12','Sub Category 2.3','sub-category-23','0'),
('13','Sub Category 3.1','sub-category-31','0'),
('14','Sub Category 3.2','sub-category-32','0'),
('15','Sub Category 3.3','sub-category-33','0'),
('16','Blockquotes','blockquotes','0'),
('17','Headlines','headlines','0'),
('18','Images Centered','images-centered','0'),
('19','Images Left','images-left','0'),
('20','Images Right','images-right','0'),
('21','Ordered Lists','ordered-lists','0'),
('22','Threaded Comments','threaded-comments','0'),
('23','Unordered Lists','unordered-lists','0'),
('24','Primary Navigation','primary-navigation','0'),
('25','Secondary Navigation','secondary-navigation','0'),
('26','Social Navigation','social-navigation','0');

DROP TABLE IF EXISTS `wp_terms`;
RENAME TABLE `wp_terms_7eVrCiFOsqnL` TO `wp_terms`;